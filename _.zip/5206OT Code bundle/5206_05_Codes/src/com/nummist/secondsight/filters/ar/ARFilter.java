package com.nummist.secondsight.filters.ar;

import com.nummist.secondsight.filters.Filter;

public interface ARFilter extends Filter {
    public float[] getGLPose();
}
